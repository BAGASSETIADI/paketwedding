<br />
<font size='1'>
    <table class='xdebug-error xe-warning' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
        <tr>
            <th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Warning: Undefined global variable $_SESSION in C:\wamp64\www\people\marni-wo\pages\payment\place-order.php on line <i>21</i></th>
        </tr>
        <tr>
            <th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th>
        </tr>
        <tr>
            <th align='center' bgcolor='#eeeeec'>#</th>
            <th align='left' bgcolor='#eeeeec'>Time</th>
            <th align='left' bgcolor='#eeeeec'>Memory</th>
            <th align='left' bgcolor='#eeeeec'>Function</th>
            <th align='left' bgcolor='#eeeeec'>Location</th>
        </tr>
        <tr>
            <td bgcolor='#eeeeec' align='center'>1</td>
            <td bgcolor='#eeeeec' align='center'>0.0006</td>
            <td bgcolor='#eeeeec' align='right'>365248</td>
            <td bgcolor='#eeeeec'>{main}( )</td>
            <td title='C:\wamp64\www\people\marni-wo\pages\payment\place-order.php' bgcolor='#eeeeec'>...\place-order.php<b>:</b>0</td>
        </tr>
    </table>
</font>
<br />
<font size='1'>
    <table class='xdebug-error xe-warning' dir='ltr' border='1' cellspacing='0' cellpadding='1'>
        <tr>
            <th align='left' bgcolor='#f57900' colspan="5"><span style='background-color: #cc0000; color: #fce94f; font-size: x-large;'>( ! )</span> Warning: Trying to access array offset on value of type null in C:\wamp64\www\people\marni-wo\pages\payment\place-order.php on line <i>21</i></th>
        </tr>
        <tr>
            <th align='left' bgcolor='#e9b96e' colspan='5'>Call Stack</th>
        </tr>
        <tr>
            <th align='center' bgcolor='#eeeeec'>#</th>
            <th align='left' bgcolor='#eeeeec'>Time</th>
            <th align='left' bgcolor='#eeeeec'>Memory</th>
            <th align='left' bgcolor='#eeeeec'>Function</th>
            <th align='left' bgcolor='#eeeeec'>Location</th>
        </tr>
        <tr>
            <td bgcolor='#eeeeec' align='center'>1</td>
            <td bgcolor='#eeeeec' align='center'>0.0006</td>
            <td bgcolor='#eeeeec' align='right'>365248</td>
            <td bgcolor='#eeeeec'>{main}( )</td>
            <td title='C:\wamp64\www\people\marni-wo\pages\payment\place-order.php' bgcolor='#eeeeec'>...\place-order.php<b>:</b>0</td>
        </tr>
    </table>
</font>
{"status":"error","message":"Customer ID not found for user: "}