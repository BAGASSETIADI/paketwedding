<?php
require('../../assets/vendors/fpdf/fpdf.php');
require_once '../config/connection.php';

// Memastikan tidak ada keluaran sebelumnya
ob_start();

if (isset($_POST['tahun'])) {
    $tahun = $_POST['tahun'];

    // Query data pesanan berdasarkan tahun
    $sql = "SELECT p.*, pl.*, IFNULL(t.deskripsi, 'Tidak ada deskripsi') AS deskripsi
            FROM pemesanan p 
            JOIN paket_layanan pl ON p.id_paket_layanan = pl.id_paket_layanan
            LEFT JOIN transaksi t ON p.id_pemesanan = t.id_pemesanan 
            WHERE YEAR(p.tanggal_pemesanan) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $tahun);
    $stmt->execute();
    $result = $stmt->get_result();

    // Inisialisasi PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);

    // Judul laporan
    $pdf->Cell(0, 10, 'Laporan Pesanan Tahunan', 0, 1, 'C');
    $pdf->Cell(0, 10, 'Tahun: ' . $tahun, 0, 1, 'C');
    $pdf->Ln(10);

    // Header tabel
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(40, 10, 'ID Pesanan', 1);
    $pdf->Cell(60, 10, 'Nama Paket', 1);
    $pdf->Cell(40, 10, 'Tanggal Pesanan', 1);
    $pdf->Cell(40, 10, 'Deskripsi', 1);
    $pdf->Ln();

    // Data tabel
    $pdf->SetFont('Arial', '', 10);
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(40, 10, $row['id_pemesanan'], 1);
        $pdf->Cell(60, 10, $row['nama_paket'], 1);
        $pdf->Cell(40, 10, $row['tanggal_pemesanan'], 1);
        $pdf->Cell(40, 10, $row['deskripsi'], 1);
        $pdf->Ln();
    }

    $stmt->close();
    $conn->close();

    // Bersihkan buffer keluaran
    ob_end_clean();

    // Output PDF
    $pdf->Output('D', 'Laporan_Tahunan_' . $tahun . '.pdf');
}
