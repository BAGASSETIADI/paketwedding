<?php
require('../../assets/vendors/fpdf/fpdf.php');
require_once '../config/connection.php';

if (isset($_POST['bulan']) && isset($_POST['tahun'])) {
    $bulan = $_POST['bulan'];
    $tahun = $_POST['tahun'];

    // Query data pesanan berdasarkan bulan dan tahun
    $sql = "SELECT p.*, pl.*
            FROM pemesanan p 
            JOIN paket_layanan pl ON p.id_paket_layanan = pl.id_paket_layanan 
            WHERE MONTH(p.tanggal_pemesanan) = ? AND YEAR(p.tanggal_pemesanan) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $bulan, $tahun);
    $stmt->execute();
    $result = $stmt->get_result();

    // Inisialisasi PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);

    // Judul laporan
    $pdf->Cell(0, 10, 'Laporan Pesanan Bulanan', 0, 1, 'C');
    $pdf->Cell(0, 10, 'Bulan: ' . $bulan . ' Tahun: ' . $tahun, 0, 1, 'C');
    $pdf->Ln(10);

    // Header tabel
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(40, 10, 'ID Pesanan', 1);
    $pdf->Cell(60, 10, 'Nama Paket', 1);
    $pdf->Cell(40, 10, 'Tanggal Pesanan', 1);
    // $pdf->Cell(40, 10, 'Status', 1);
    $pdf->Ln();

    // Data tabel
    $pdf->SetFont('Arial', '', 10);
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(40, 10, $row['id_pemesanan'], 1);
        $pdf->Cell(60, 10, $row['nama_paket'], 1);
        $pdf->Cell(40, 10, $row['tanggal_pemesanan'], 1);
        // $pdf->Cell(40, 10, $row['status_pesanan'], 1);
        $pdf->Ln();
    }

    $stmt->close();
    $conn->close();

    // Output PDF
    $pdf->Output('D', 'Laporan_Bulanan_' . $bulan . '_' . $tahun . '.pdf');
}
