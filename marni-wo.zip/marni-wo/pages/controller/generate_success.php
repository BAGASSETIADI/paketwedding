<?php
require('../../assets/vendors/fpdf/fpdf.php');

// Pastikan koneksi database sudah tersedia secara global atau ditambahkan di sini
require_once '../config/connection.php';

function generateInvoicePDF($orderId)
{
    global $conn; // Menggunakan koneksi database global

    // Query untuk mengambil data transaksi dan pesanan
    $sql = "SELECT t.*, p.*, pl.nama_paket
            FROM transaksi t
            JOIN pemesanan p ON t.id_pemesanan = p.id_pemesanan
            JOIN paket_layanan pl ON p.id_paket_layanan = pl.id_paket_layanan
            WHERE t.id_pemesanan = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $orderId); // Gunakan 's' jika orderId adalah string
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!$result) {
        error_log("No data found for orderId: $orderId");
        return null;
    }

    // Inisialisasi PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);

    // Header
    $pdf->Cell(0, 10, 'Invoice', 0, 1, 'C');
    $pdf->Ln(10);

    // Details
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(40, 10, 'ID Pemesanan:', 0, 0);
    $pdf->Cell(0, 10, $result['id_pemesanan'], 0, 1);
    $pdf->Cell(40, 10, 'Nama Paket:', 0, 0);
    $pdf->Cell(0, 10, $result['nama_paket'], 0, 1);
    $pdf->Cell(40, 10, 'Tanggal Pemesanan:', 0, 0);
    $pdf->Cell(0, 10, $result['tanggal_pemesanan'], 0, 1);
    $pdf->Cell(40, 10, 'Nama Pelanggan:', 0, 0);
    $pdf->Cell(0, 10, $result['nama_pelanggan'], 0, 1);
    $pdf->Cell(40, 10, 'Tanggal Acara:', 0, 0);
    $pdf->Cell(0, 10, $result['tanggal_acara'], 0, 1);
    $pdf->Cell(40, 10, 'Kontak Pemesan:', 0, 0);
    $pdf->Cell(0, 10, $result['kontak_pemesan'], 0, 1);
    $pdf->Cell(40, 10, 'Alamat Acara:', 0, 0);
    $pdf->Cell(0, 10, $result['alamat_acara'], 0, 1);
    $pdf->Cell(40, 10, 'Harga:', 0, 0);
    $pdf->Cell(0, 10, number_format($result['total'], 0, ',', '.'), 0, 1);

    // Direktori dan jalur file PDF
    $invoiceDir = '../invoices/';
    if (!file_exists($invoiceDir)) {
        mkdir($invoiceDir, 0755, true); // Buat direktori jika belum ada
    }
    $invoicePath = $invoiceDir . 'invoice_' . $orderId . '.pdf';

    // Simpan PDF
    $pdf->Output('F', $invoicePath);

    return $invoicePath;
}
