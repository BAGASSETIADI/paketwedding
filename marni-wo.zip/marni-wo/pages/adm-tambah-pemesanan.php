<?php
if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit;
}

// Periksa apakah user adalah admin
if ($_SESSION['user']['role'] != 1) {
    // header('Location: plg-main.php');
    exit;
}

include('config/connection.php');

$query_paket_layanan = "SELECT * FROM paket_layanan";
$result = $conn->query($query_paket_layanan);

$paket_layanan = [];
while ($row = $result->fetch_assoc()) {
    $paket_layanan[] = $row;
}
if (isset($_POST['submit'])) {
    $random_number = rand(1, 9999);
    $id_pemesanan = "PSN" . $random_number;
    // $tanggal_pemesanan = date('Y-m-d');
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $tanggal_acara = $_POST['tgl_acara'];
    $paket_layanan = $_POST['paket_layanan'];
    $harga_str = $_POST['harga'];
    $harga_str = str_replace('Rp ', '', $harga_str); // Menghapus "Rp "
    $harga_str = str_replace('.', '', $harga_str); // Menghapus tanda titik
    $harga = intval($harga_str); // Konversi ke integer
    $kontak_pemesan = $_POST['kontak_pemesan'];
    $alamat_acara = $_POST['alamat_acara'];
    $catatan_khusus = $_POST['catatan'];

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Buat query INSERT
    $sql = "INSERT INTO pemesanan (id_pemesanan, tanggal_pemesanan, nama_pelanggan, tanggal_acara, id_paket_layanan, kontak_pemesan, alamat_acara, status_pesanan, catatan_khusus) 
    VALUES ('$id_pemesanan', CURRENT_TIME, '$nama_pelanggan', '$tanggal_acara', '$paket_layanan', '$kontak_pemesan', '$alamat_acara', 0, '$catatan_khusus')";

    if ($conn->multi_query($sql) === TRUE) {
        echo "<script type='text/javascript'>Swal.fire('Berhasil!', 'Data berhasil disimpan.', 'success');</script>";
    } else {
        echo "<script type='text/javascript'>Swal.fire('Gagal!', 'Data tidak berhasil disimpan. Silakan coba lagi.', 'error');</script>";
    }
    $conn->close();
}

?>
<main class="app-main"> <!--begin::App Content Header-->
    <div class="app-content-header"> <!--begin::Container-->
        <div class="container-fluid"> <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Tambah Pemesanan</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="?page=pemesanan">Pemesanan</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Tambah Pemesanan
                        </li>
                    </ol>
                </div>
            </div> <!--end::Row-->
        </div> <!--end::Container-->
    </div>
    <div class="p-4 mb-4"> <!--begin::Header-->
        <form method="post"> <!--begin::Body-->
            <div class="body">
                <div class="row mb-3"> <label for="nama" class="col-sm-2 col-form-label">Nama Pemesan</label>
                    <div class="col-sm-10"> <input type="text" name="nama_pelanggan" class="form-control" id="nama" required> </div>
                </div>
                <div class="row mb-3"> <label for="tgl_pemesanan" class="col-sm-2 col-form-label">Tanggal Acara</label>
                    <div class="col-sm-10"> <input type="date" name="tgl_acara" class="form-control" id="tgl_pemesanan" required> </div>
                </div>
                <div class="row mb-3">
                    <label for="paket_layanan" class="col-sm-2 col-form-label">Paket Layanan</label>
                    <div class="col-sm-10">
                        <select class="js-example-basic-single pilih-paket form-control" name="paket_layanan">
                            <option value="">Pilih Paket Layanan</option>
                            <?php foreach ($paket_layanan as $p) { ?>
                                <option value="<?= $p['id_paket_layanan'] ?>" data-harga="<?= $p['harga'] ?>">
                                    <?= $p['nama_paket'] ?>
                                </option>
                            <?php } ?>
                        </select>

                    </div>
                </div>
                <div class="row mb-3">
                    <label for="harga" class="col-sm-2 col-form-label">Harga</label>
                    <div class="col-sm-10">
                        <input type="text" name="harga" class="form-control" id="harga" readonly>
                    </div>
                </div>


                <div class="row mb-3"> <label for="kontak_pemesan" class="col-sm-2 col-form-label">Kontak Pemesan</label>
                    <div class="col-sm-10"> <input type="text" name="kontak_pemesan" class="form-control" id="kontak_pemesan" required> </div>
                </div>
                <div class="row mb-3"> <label for="alamat_acara" class="col-sm-2 col-form-label">Alamat Acara</label>
                    <div class="col-sm-10"> <input type="text" name="alamat_acara" class="form-control" id="alamat_acara" required> </div>
                </div>
                <div class="row mb-3"> <label for="catatan" class="col-sm-2 col-form-label">Catatan</label>
                    <div class="col-sm-10">
                        <textarea name="catatan" id="catatan" class="form-control"></textarea>
                    </div>
                </div> <!--end::Body--> <!--begin::Footer-->
                <div class="card-footer"> <button type="submit" name="submit" class="btn btn-warning">Bayar</button> <button type="reset" class="btn float-end">Batal</button> </div> <!--end::Footer-->
        </form> <!--end::Form-->
    </div> <!--end::Horizontal Form-->
</main>