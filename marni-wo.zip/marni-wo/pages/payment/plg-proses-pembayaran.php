<?php
require_once dirname(__FILE__) . '/midtrans/Midtrans.php';
require_once '../config/connection.php'; // Ganti dengan file konfigurasi database Anda

// Set your Merchant Server Key
\Midtrans\Config::$serverKey = 'SB-Mid-server-nOxjhOn7sC3KNo_vtPYxIh2U';
// Set to Development/Sandbox Environment (default). Set to true for Production Environment (accept real transaction).
\Midtrans\Config::$isProduction = false;
// Set sanitization on (default)
\Midtrans\Config::$isSanitized = true;
// Set 3DS transaction for credit card to true
\Midtrans\Config::$is3ds = true;

// Disable error output to prevent HTML being sent
ini_set('display_errors', 0);
error_reporting(E_ERROR | E_PARSE);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_transaksi = $_POST['id_transaksi'];

    // Fetch transaction details from the database
    $sql = "SELECT t.*, p.nama_pelanggan FROM transaksi t JOIN pemesanan p ON t.id_pemesanan = p.id_pemesanan WHERE t.id_transaksi = '$id_transaksi'";
    $result = $conn->query($sql);
    $transaction = $result->fetch_assoc();

    if ($transaction) {
        // Check if the transaction has a snap token already
        if (!empty($transaction['snap_token'])) {
            // If snap token exists, use it
            echo json_encode(['status' => 'success', 'snapToken' => $transaction['snap_token']]);
        } else {
            $params = array(
                'transaction_details' => array(
                    'order_id' => $transaction['id_pemesanan'],
                    'gross_amount' => $transaction['total'],
                ),
                'customer_details' => array(
                    'first_name' => $transaction['nama_pelanggan'],
                    'email' => $transaction['email'],
                ),
            );

            try {
                $snapToken = \Midtrans\Snap::getSnapToken($params);

                // Save snap token to the database
                $updateSql = "UPDATE transaksi SET id_pembayaran_midtrans = '$snapToken' WHERE id_transaksi = '$id_transaksi'";
                $conn->query($updateSql);

                echo json_encode(['status' => 'success', 'snapToken' => $snapToken]);
            } catch (Exception $e) {
                echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Transaction not found.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
